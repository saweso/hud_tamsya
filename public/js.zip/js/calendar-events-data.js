var calendarEvents= [
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-01-01'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-01-03'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-01-22',
        end: '2018-01-23'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2018-01-23T16:00:00'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2018-01-23T16:00:00'
    },
    {
        title: 'Conference',
        start: '2018-01-11',
        end: '2018-01-13'
    },
    {
        title: 'Meeting',
        start: '2018-01-12T10:30:00',
        end: '2018-01-12T12:30:00'
    },
    {
        title: 'Lunch',
        start: '2018-01-12T12:00:00'
    },
    {
        title: 'Meeting',
        start: '2018-01-12T14:30:00'
    },
    {
        title: 'Dinner',
        start: '2018-01-12T20:00:00'
    },
    


    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-02-02'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-02-04'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-02-22',
        end: '2018-02-23'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2018-02-23T16:00:00'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2018-02-23T16:00:00'
    },
    {
        title: 'Conference',
        start: '2018-02-11',
        end: '2018-02-13'
    },
    {
        title: 'Meeting',
        start: '2018-02-12T10:30:00',
        end: '2018-02-12T12:30:00'
    },
    {
        title: 'Lunch',
        start: '2018-02-12T12:00:00'
    },
    {
        title: 'Meeting',
        start: '2018-02-12T14:30:00'
    },
    {
        title: 'Dinner',
        start: '2018-01-12T20:00:00'
    },
    


    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-03-01'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-03-02'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2018-03-21',
        end: '2018-03-22'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2018-03-23T16:00:00'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2018-03-23T16:00:00'
    },
    {
        title: 'Conference',
        start: '2018-03-11',
        end: '2018-03-13'
    },
    {
        title: 'Meeting',
        start: '2018-03-12T10:30:00',
        end: '2018-03-12T12:30:00'
    },
    {
        title: 'Lunch',
        start: '2018-03-12T12:00:00'
    },
    {
        title: 'Meeting',
        start: '2018-03-12T14:30:00'
    },
    {
        title: 'Dinner',
        start: '2018-03-12T20:00:00'
    }
];