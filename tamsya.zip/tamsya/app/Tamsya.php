<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tamsya extends Model
{
    //
}
